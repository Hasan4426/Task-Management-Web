import React from 'react'
import { createRoot } from 'react-dom/client'
import { AuthProvider } from './features/auth/AuthContext.jsx'
import App from './App.jsx'
import './styles.css'

createRoot(document.getElementById('root')).render(
  <React.StrictMode><AuthProvider><App /></AuthProvider></React.StrictMode>,
)
